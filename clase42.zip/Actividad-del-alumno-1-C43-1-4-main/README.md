Actividad del alumno 1 C43 1-4
